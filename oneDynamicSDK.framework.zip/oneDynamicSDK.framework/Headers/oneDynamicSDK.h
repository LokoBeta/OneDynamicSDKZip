//
//  oneDynamicSDK.h
//  oneDynamicSDK
//
//  Created by Lincal on 2019/4/19.
//  Copyright © 2019 polyv. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "oneDynamicClassHello.h"

//! Project version number for oneDynamicSDK.
FOUNDATION_EXPORT double oneDynamicSDKVersionNumber;

//! Project version string for oneDynamicSDK.
FOUNDATION_EXPORT const unsigned char oneDynamicSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <oneDynamicSDK/PublicHeader.h>


